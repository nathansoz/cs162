Lab 3
=====

Combines numbers from two files in order. Numbers in the source files must already be in order.

Right now, you must edit file1.txt and file2.txt, as these files are hardcoded into the program. Future improvements may involve allowing for command line arguments.